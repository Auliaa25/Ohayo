export interface FormatVerify {
	otp: string
	hit: number
	status: boolean
	open: boolean
}