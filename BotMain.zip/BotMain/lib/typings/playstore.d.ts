export declare class PlayStore {
	title: string;
	description: string;
	icon: string;
	rating: string;
	developer: string;
	link: string
}