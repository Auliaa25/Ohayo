export declare class GIS {
	url: string;
	width: number;
	height: number;
}
export declare class Googlesearch {
	title: string;
	link: string;
	snippet: string
}