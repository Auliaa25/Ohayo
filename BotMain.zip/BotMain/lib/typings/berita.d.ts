export interface KompasTerkini {
	url: string
	judul: string;
	tanggal: string
}